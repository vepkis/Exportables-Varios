/*
  GrabadorDeTonos.cpp - 
  Libreria para grabar y reproducir tonos a partir de una señal análoga.
  Creada por Krista Yorbyck , Julio , 2019.
*/

#ifndef GrabadorDeTonos_h
#define GrabadorDeTonos_h

#include "Arduino.h"



class GrabadorDeTonos
{
public:
	GrabadorDeTonos(int microfonoPIN_, int parlante_, int ledRegistro_,int tiempoRegistro_, int sonidoMinUmbral_);

	void muestraValor();
	void grabaSonido();
	void reproduceSonido();
  void reproduceSonidoEspecial(int index_, int delayVariable_);
  int muestreo(int freqMin_, int freqMax_);
	void tiempoDeEspera(int tope_);
	void reiniciaCronometro(boolean reinicia_);
	void updateGrabacion();
    int sampleWindow=50; // Ancho ventana en mS (50 mS = 20Hz)
    int microfonoPIN;

void setSeparadorReproduccion(int milisegundos_);

    bool getGrabando();
    bool getDisponible();
    bool getEsperaTermino();
    bool getReproduciendo();

private:

	int parlante;
    int contador;//definir a quien pertenece
    int tope;
    int tiempoRegistro; 
   int registro_[200];//tamaño máximo reservado que se puede usar en el registro
   int sonidoMinUmbral;//determina desde que valores reproduce recomendado 60

//-----variables de tiempo de espera
   int esperaCronometro;
   int esperaTope=11;
   boolean esperaTermino= false;
//-----

   boolean grabando;
   boolean almacena= true;

   boolean disponible= true;

   boolean reproduciendo= false;


    int separadorReproduccion;


   int ledGrabador=13;
   int ledRegistro;

};

#endif

