/*
  GrabadorDeTonos.cpp -
  Libreria para grabar y reproducir tonos a partir de una señal análoga.
  Creada por Krista Yorbyck , Julio , 2019.
*/

#include "Arduino.h"
#include "GrabadorDeTonos.h"



GrabadorDeTonos:: GrabadorDeTonos(int microfonoPIN_, int parlante_, int ledRegistro_,int tiempoRegistro_, int sonidoMinUmbral_)
{

  ledRegistro=ledRegistro_;

  pinMode(microfonoPIN_, INPUT);
  pinMode(ledGrabador, OUTPUT);
  pinMode(ledRegistro, OUTPUT);

  digitalWrite(ledGrabador,LOW);
  digitalWrite(ledRegistro,LOW);

  microfonoPIN= microfonoPIN_;
  parlante= parlante_;
  tiempoRegistro=tiempoRegistro_; 
  tope=tiempoRegistro_-1;
  sonidoMinUmbral= sonidoMinUmbral_;


}
void GrabadorDeTonos::muestraValor()
{

//Serial.println(sizeof(registro_)/ sizeof(registro_[0]));
 // Serial.println(tiempoDeEspera(0,20));



  tiempoDeEspera(esperaTope);

}

void GrabadorDeTonos::grabaSonido()
{

 if (contador < tope && almacena)
 {
  grabando = true;
  digitalWrite(ledGrabador, HIGH);
  registro_[contador]= muestreo(40, 10000);

  Serial.print(contador);

  Serial.print("______");

  Serial.println(registro_[contador]);

  contador++;
}

if (contador == tope && almacena == true)
{
  Serial.println("--- endLine ---");

  almacena = false;

  grabando = false;
  disponible= false;
  digitalWrite(ledGrabador, LOW);
  digitalWrite(ledRegistro, HIGH);
}



}

void GrabadorDeTonos::reproduceSonido()

{
  Serial.println("________________________");
  Serial.print("___INICIO DE REGISTRO___");
  Serial.println("\n");
  reproduciendo= true;

  for (int i = 0; i < tiempoRegistro; i++)
  {
    if (almacena == false)
    {
      if (registro_[i] > sonidoMinUmbral)
      {
        tone(parlante, registro_[i], 20);
      }
      else
      {
        noTone(parlante);
      }


      if (i==tiempoRegistro-1)
      {
        Serial.println("___FIN DE REGISTRO___");
        Serial.println("________________________");

        Serial.println("\n");
        reproduciendo= false;

      }
      else{
        Serial.println(registro_[i]);
      }

      delay(sampleWindow);

    }

  }

  delay(separadorReproduccion);

}



void GrabadorDeTonos::reproduceSonidoEspecial(int index_, int delayVariable_)

{

  if (registro_[index_] > sonidoMinUmbral)
  {
    tone(parlante, registro_[index_]);
  }
  else
  {
    noTone(parlante);
  }
  delay(delayVariable_);
  noTone(parlante);
  delay(separadorReproduccion);
  Serial.println(index_);

}



int GrabadorDeTonos::muestreo(int freqMin_, int freqMax_)
{

  unsigned long startMillis = millis();

  unsigned int signalMax = 0;
  unsigned int signalMin = 1024;

  // Recopilar durante la ventana
  unsigned int sample;


  while (millis() - startMillis < sampleWindow)
  {
    sample = analogRead(microfonoPIN);

    if (sample > signalMax)
    {
      signalMax = sample;  // Actualizar máximo
    }
    else if (sample < signalMin)
    {
      signalMin = sample;  // Actualizar mínimo
    }
  }

  unsigned int amplitud = signalMax - signalMin;  // Amplitud del sonido pico a pico
  int thisPitch = map(amplitud, 0, 800, freqMin_, freqMax_);


  return thisPitch;
}



void GrabadorDeTonos::tiempoDeEspera(int tope_)
{

  if(esperaCronometro< tope_ && esperaTermino==false)
  {
    esperaCronometro++;
    Serial.print("CRONOMETRO__");
    Serial.print("\t");
    Serial.println(esperaCronometro);


  }
  if(esperaCronometro == tope_)
  {
    esperaTermino= true;
    Serial.println("__ESPERA TERMINADA__");
  }


}

void GrabadorDeTonos:: reiniciaCronometro(boolean reinicia_)
{
  if (reinicia_)
  {
    esperaTermino=false;
    esperaCronometro=0;

  }

}

void GrabadorDeTonos :: updateGrabacion()
{

  almacena= true;
  contador=0;
  esperaCronometro=0;
  esperaTermino=false;
  disponible= true;
  digitalWrite(ledRegistro,LOW);


}






//----------------------------- v S E T T E R S

void GrabadorDeTonos :: setSeparadorReproduccion(int milisegundos_)
{

  separadorReproduccion = milisegundos_;
}



//----------------------------- v G E T T E R S

bool GrabadorDeTonos :: getGrabando()
{

  return grabando;
}

bool GrabadorDeTonos :: getDisponible()
{

  return disponible;
}

bool GrabadorDeTonos :: getEsperaTermino()
{

  return esperaTermino;
}

bool GrabadorDeTonos :: getReproduciendo()
{

  return reproduciendo;
}


